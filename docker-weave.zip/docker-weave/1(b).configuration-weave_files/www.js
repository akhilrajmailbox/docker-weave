/* Copyright 2011-2017 HeatMap Inc. - All rights reserved */
window.heatmap_ext = window.heatmap_ext || {};

heatmap_ext.bcr = true;
heatmap.log.start(29508,"eu5",1483966392);
